public class Dog1 {

    public static void main(String[] args) {
        KeyWords Afghan=new KeyWords("Afgan Hound","black, red, cream","fine","large","floppy","long",
                "dignified,Aloof, Independant",)
    }

}
