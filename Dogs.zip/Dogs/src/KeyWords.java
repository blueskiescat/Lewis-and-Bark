public class KeyWords {


    //Colors Coat type Size (Toy, small, medium, large, extra large) Life expectancy Ear shape Face shape Temperament Energy level Group AKC recognized? (yes/no) Purebred? (yes/no)
    private String name;
    private String colors;
    private String coatType;
    private String size;
    private String earShape;
    private String faceShape;
    private String temperment;
    private String energy;
    private int lifeLenght;
    private boolean isAKC;
    private boolean ispurebread;
    private boolean ishypoallergenic;

    public KeyWords(String name, String colors, String coatType, String size, String earShape, String faceShape, String temperment,
                    String energy, int lifeLenght, boolean isAKC, boolean ispurebread,boolean ishypoallergenic) {
        this.name=name;
        this.colors=colors;
        this.coatType=coatType;
        this.size=size;
        this.earShape=earShape;
        this.faceShape=faceShape;
        this.temperment=temperment;
        this.energy=energy;
        this.lifeLenght=lifeLenght;
        this.isAKC=isAKC;
        this.lifeLenght=lifeLenght;
        this.ispurebread=ispurebread;
        this.ishypoallergenic=ishypoallergenic;
    }


}